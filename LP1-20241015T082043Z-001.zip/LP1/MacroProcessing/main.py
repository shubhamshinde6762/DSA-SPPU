from utils import *

if (__name__ == "__main__"):
    p = Process()
    p.process()
    p2 = Pass2()
    p2.process()